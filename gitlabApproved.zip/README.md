# gitlabApproved
Chrome extension to show how many approves an MR has
